﻿namespace FelicidApp.Model
{
    public class SummaryData
    {
        public string Mood { get; set; }
    }
}
