﻿public enum Mood
{
    Happiness,
    Sadness,
    Surprise,
    Anger,
    Fear,
    Contempt,
    Disgust,
    Neutral
}
